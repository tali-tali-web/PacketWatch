"""PacketWatch: statistical comparison of normal vs malicious traffic (UNSW-NB15)."""
import glob
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st
from scipy import stats

st.set_page_config(page_title="PacketWatch", page_icon="🛡️", layout="wide")

BLUE, PINK = "#00e5ff", "#ff2e97"
BG, PANEL, TEXT = "#0b0f1a", "#121829", "#e6f1ff"
COLORS = {"Normal": BLUE, "Malicious": PINK}
HERE = os.path.dirname(os.path.abspath(__file__))
NEEDED = ["spkts", "dpkts", "dur", "sbytes", "dbytes", "proto", "label"]

st.markdown(
    f"""
    <style>
    .stApp {{ background: {BG}; color: {TEXT}; }}
    section[data-testid="stSidebar"] {{ background: {PANEL}; border-right: 1px solid {BLUE}33; }}
    h1, h2, h3 {{ color: {TEXT}; letter-spacing: .5px; }}
    h1 span {{ color: {BLUE}; }}
    h2 {{ border-left: 4px solid {PINK}; padding-left: 10px; margin-top: 1.5rem; }}
    div[data-testid="stMetric"] {{
        background: {PANEL}; border: 1px solid {BLUE}55; border-radius: 10px;
        padding: 12px 16px; transition: all .2s ease;
    }}
    div[data-testid="stMetric"]:hover {{ border-color: {PINK}; box-shadow: 0 0 14px {PINK}66; }}
    div[data-testid="stMetricValue"] {{ color: {BLUE}; }}
    </style>
    """,
    unsafe_allow_html=True,
)


# ---------------------------------------------------------------- data loading
@st.cache_data(show_spinner="Loading dataset...")
def load_data():
    paths = sorted(
        glob.glob(os.path.join(HERE, "*.csv")) + glob.glob(os.path.join(HERE, "data", "*.csv"))
    )
    frames = []
    for p in paths:
        try:
            df = pd.read_csv(p)
        except Exception:
            continue
        df.columns = [c.strip().lower() for c in df.columns]
        if all(c in df.columns for c in NEEDED):
            df["source_file"] = os.path.basename(p)
            frames.append(df)
    if not frames:
        return synthetic_data(), "Synthetic demo data (no UNSW-NB15 CSV found)", 0
    data = pd.concat(frames, ignore_index=True)
    before = len(data)
    subset = [c for c in data.columns if c not in ("id", "source_file")]
    data = data.drop_duplicates(subset=subset).reset_index(drop=True)
    return data, f"UNSW-NB15 ({len(frames)} file(s))", before - len(data)


def synthetic_data(n=20000, seed=42):
    rng = np.random.default_rng(seed)
    label = (rng.random(n) < 0.55).astype(int)
    spkts = np.where(label == 1, rng.lognormal(2.4, 1.2, n), rng.lognormal(2.0, 1.0, n)).astype(int) + 1
    dpkts = np.where(label == 1, rng.lognormal(1.4, 1.5, n), rng.lognormal(1.9, 1.0, n)).astype(int)
    return pd.DataFrame({
        "spkts": spkts, "dpkts": dpkts,
        "dur": np.where(label == 1, rng.lognormal(-3, 2.5, n), rng.lognormal(-2, 2.0, n)),
        "sbytes": spkts * rng.integers(40, 900, n),
        "dbytes": dpkts * rng.integers(40, 1400, n),
        "proto": rng.choice(["tcp", "udp", "icmp", "arp", "ospf", "sctp"], n,
                            p=[.55, .30, .06, .04, .03, .02]),
        "label": label,
        "attack_cat": np.where(label == 1,
                               rng.choice(["Generic", "Exploits", "Fuzzers", "DoS"], n), "Normal"),
    })


df, source_note, n_dupes = load_data()
df = df.copy()
df["total_packets"] = df["spkts"] + df["dpkts"]
df["group"] = df["label"].map({0: "Normal", 1: "Malicious"})
normal = df.loc[df["label"] == 0, "total_packets"]
malicious = df.loc[df["label"] == 1, "total_packets"]


# ---------------------------------------------------------------- plot helpers
def style(ax, title="", xlabel="", ylabel=""):
    ax.set_facecolor(PANEL)
    ax.figure.set_facecolor(PANEL)
    ax.set_title(title, color=TEXT, fontsize=11, pad=10)
    ax.set_xlabel(xlabel, color=TEXT)
    ax.set_ylabel(ylabel, color=TEXT)
    ax.tick_params(colors=TEXT)
    for s in ax.spines.values():
        s.set_color("#ffffff22")
    ax.grid(color="#ffffff12", linewidth=0.6)
    ax.set_axisbelow(True)


def grouped_bars(ax, labels, normal_vals, mal_vals, log=False):
    x = np.arange(len(labels))
    w = 0.38
    ax.bar(x - w / 2, normal_vals, w, color=BLUE, label="Normal")
    ax.bar(x + w / 2, mal_vals, w, color=PINK, label="Malicious")
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    if log:
        ax.set_yscale("log")
    leg = ax.legend(facecolor=PANEL, edgecolor="#ffffff22")
    for t in leg.get_texts():
        t.set_color(TEXT)


# ---------------------------------------------------------------- sidebar
st.sidebar.title("🛡️ Controls")
st.sidebar.caption("These controls change chart display only. The hypothesis test always uses the full dataset.")
log_scale = st.sidebar.checkbox("Log scale (recommended)", value=True)
top_n = st.sidebar.slider("Protocols to show", 3, 12, 6)
show_outliers = st.sidebar.checkbox("Show box plot outliers", value=False)
alpha = st.sidebar.selectbox("Significance level (α)", [0.05, 0.01, 0.10], index=0)
st.sidebar.markdown("---")
st.sidebar.caption(f"Data source: {source_note}")

# ---------------------------------------------------------------- header
st.markdown("# <span>Packet</span>Watch", unsafe_allow_html=True)
st.caption("Statistical analysis of differences between normal and malicious network traffic")
if "Synthetic" in source_note:
    st.warning("No UNSW-NB15 CSV found in the project folder, so synthetic demo data is shown. "
               "Put the dataset CSVs next to app.py (or in a data/ folder) and restart.")

# ---------------------------------------------------------------- overview
st.header("Overview")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Total records", f"{len(df):,}")
c2.metric("Normal", f"{len(normal):,}")
c3.metric("Malicious", f"{len(malicious):,}")
c4.metric("Duplicates removed", f"{n_dupes:,}")

left, right = st.columns(2)
with left:
    fig, ax = plt.subplots(figsize=(5, 4))
    counts = [len(normal), len(malicious)]
    ax.pie(counts, labels=["Normal", "Malicious"], colors=[BLUE, PINK], autopct="%1.1f%%",
           textprops={"color": TEXT}, wedgeprops={"edgecolor": PANEL, "linewidth": 2})
    fig.set_facecolor(PANEL)
    ax.set_title("Share of records (dataset composition)", color=TEXT, fontsize=11)
    st.pyplot(fig)
    st.caption("This reflects how the dataset was built, not how common attacks are in real networks.")
with right:
    fig, ax = plt.subplots(figsize=(5, 4))
    grouped_bars(ax, ["Mean", "Median"],
                 [normal.mean(), normal.median()], [malicious.mean(), malicious.median()], log_scale)
    style(ax, "Total packets per connection", "", "Packets" + (" (log)" if log_scale else ""))
    st.pyplot(fig)
    st.caption("The mean is pulled up by a few very large connections; the median shows a typical one.")

# ---------------------------------------------------------------- distribution
st.header("Packet count distribution")
fig, ax = plt.subplots(figsize=(9, 4))
bp = ax.boxplot([normal, malicious], tick_labels=["Normal", "Malicious"], patch_artist=True,
                showfliers=show_outliers, medianprops={"color": "white", "linewidth": 2},
                whiskerprops={"color": TEXT}, capprops={"color": TEXT},
                flierprops={"markerfacecolor": "#ffffff55", "markeredgecolor": "none", "markersize": 2})
for patch, col in zip(bp["boxes"], [BLUE, PINK]):
    patch.set_facecolor(col)
    patch.set_alpha(0.75)
if log_scale:
    ax.set_yscale("log")
style(ax, "Total packet count per connection", "", "Packets" + (" (log)" if log_scale else ""))
st.pyplot(fig)

desc = df.groupby("group")["total_packets"].agg(
    ["count", "mean", "median", "std", "min", "max", "skew"]).round(2)
st.dataframe(desc, use_container_width=True)

# ---------------------------------------------------------------- duration & bytes
st.header("Duration and data transfer")
d1, d2 = st.columns(2)
agg = st.radio("Summary statistic", ["median", "mean"], horizontal=True)
with d1:
    fig, ax = plt.subplots(figsize=(5, 4))
    f = lambda g: getattr(df.loc[df["group"] == g, "dur"], agg)()
    grouped_bars(ax, ["Duration"], [f("Normal")], [f("Malicious")], log_scale)
    style(ax, f"{agg.title()} connection duration", "", "Seconds" + (" (log)" if log_scale else ""))
    st.pyplot(fig)
with d2:
    fig, ax = plt.subplots(figsize=(5, 4))
    vals = {g: [getattr(df.loc[df["group"] == g, c], agg)() for c in ["sbytes", "dbytes"]]
            for g in ["Normal", "Malicious"]}
    grouped_bars(ax, ["Source bytes", "Destination bytes"], vals["Normal"], vals["Malicious"], log_scale)
    style(ax, f"{agg.title()} bytes transferred", "", "Bytes" + (" (log)" if log_scale else ""))
    st.pyplot(fig)
st.caption("Many connections have a duration of 0, which strongly affects the median on a log scale.")

# ---------------------------------------------------------------- protocols
st.header("Protocol distribution")
top = df["proto"].value_counts().head(top_n).index
share = (df.assign(proto=np.where(df["proto"].isin(top), df["proto"], "other"))
         .groupby(["group", "proto"]).size().unstack(fill_value=0))
share = share.div(share.sum(axis=1), axis=0) * 100
order = list(top) + (["other"] if "other" in share.columns else [])
share = share.reindex(columns=order, fill_value=0)
fig, ax = plt.subplots(figsize=(9, 4))
grouped_bars(ax, order, share.loc["Normal"], share.loc["Malicious"])
style(ax, f"Top {top_n} protocols, share within each group", "Protocol", "% of group")
st.pyplot(fig)

# ---------------------------------------------------------------- hypothesis test
st.header("Hypothesis test")
st.markdown(
    "**H₀:** mean total packets (normal) = mean total packets (malicious)  \n"
    "**H₁:** the two means are different (two-tailed)"
)
t_stat, p_val = stats.ttest_ind(normal, malicious, equal_var=False)
n1, n2 = len(normal), len(malicious)
m1, m2 = normal.mean(), malicious.mean()
v1, v2 = normal.var(ddof=1), malicious.var(ddof=1)
pooled_sd = np.sqrt(((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2))
cohens_d = (m1 - m2) / pooled_sd
se = np.sqrt(v1 / n1 + v2 / n2)
dof = (v1 / n1 + v2 / n2) ** 2 / ((v1 / n1) ** 2 / (n1 - 1) + (v2 / n2) ** 2 / (n2 - 1))
tcrit = stats.t.ppf(0.975, dof)
ci = ((m1 - m2) - tcrit * se, (m1 - m2) + tcrit * se)
size = ("negligible" if abs(cohens_d) < 0.2 else "small" if abs(cohens_d) < 0.5
        else "medium" if abs(cohens_d) < 0.8 else "large")

r1, r2, r3, r4 = st.columns(4)
r1.metric("Welch t statistic", f"{t_stat:.3f}")
r2.metric("p-value", "< 0.001" if p_val < 0.001 else f"{p_val:.4f}")
r3.metric("Cohen's d", f"{cohens_d:.3f}", size)
r4.metric("α", f"{alpha}")
st.write(f"Mean difference (normal − malicious): **{m1 - m2:.2f} packets**, "
         f"95% CI [{ci[0]:.2f}, {ci[1]:.2f}]")
if p_val < alpha:
    st.success(f"p < α, so we reject H₀. The mean total packet count differs between groups, "
               f"with a {size} effect size (|d| = {abs(cohens_d):.2f}).")
else:
    st.info("p ≥ α, so we fail to reject H₀. There is not enough evidence of a difference in means.")
st.caption("Limitations: packet counts are right-skewed (the large sample size supports the t-test), "
           "flows are not fully independent, attacks are simulated, and results apply to this dataset only. "
           "A significant difference does not mean packet count is a good detection feature.")

# ---------------------------------------------------------------- data browser
st.header("Data browser")
b1, b2, b3 = st.columns(3)
view = b1.selectbox("Traffic type", ["All", "Normal", "Malicious"])
rows = b2.selectbox("Rows per page", [5, 10, 20, 50], index=1)
subset = df if view == "All" else df[df["group"] == view]
pages = max(1, int(np.ceil(len(subset) / rows)))
page = b3.number_input("Page", min_value=1, max_value=pages, value=1, step=1)
start = (page - 1) * rows
cols = [c for c in ["proto", "service", "state", "spkts", "dpkts", "total_packets", "dur",
                    "sbytes", "dbytes", "attack_cat", "group"] if c in subset.columns]
st.dataframe(subset.iloc[start:start + rows][cols], use_container_width=True, hide_index=True)
st.caption(f"Page {page} of {pages:,} · {len(subset):,} records")
