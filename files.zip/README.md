# PacketWatch

Streamlit dashboard comparing normal and malicious network traffic in the UNSW-NB15 dataset.
Research question: is the mean total packet count (`spkts + dpkts`) different between the two groups?

## Project structure
```
packetwatch/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── data/            (optional; put the CSVs here or next to app.py)
```

## Run
```
pip install -r requirements.txt
streamlit run app.py
```

## Data
Download `UNSW_NB15_training-set.csv` and `UNSW_NB15_testing-set.csv` from the official UNSW page and
place them next to `app.py` or in `data/`. They are merged and duplicates removed (ignoring `id`).
With no CSV present, a synthetic demo dataset is used so the app still runs.
The CSVs are git-ignored because of their size.

## Method
One Welch's independent-samples t-test (two-tailed, default α = 0.05) on the full dataset, with
Cohen's d and a 95% confidence interval. Sidebar controls only affect chart display, never the test.

## Limitations
Simulated attacks, artificial class balance, non-independent flows, pooled attack categories,
and results specific to this dataset.

## Citations
- Moustafa, N., & Slay, J. (2015). UNSW-NB15: A comprehensive data set for network intrusion detection systems. MilCIS, IEEE.
- Moustafa, N., & Slay, J. (2016). The evaluation of Network Anomaly Detection Systems: Statistical analysis of the UNSW-NB15 data set and the comparison with the KDD99 data set. Information Security Journal: A Global Perspective, 1-14.
